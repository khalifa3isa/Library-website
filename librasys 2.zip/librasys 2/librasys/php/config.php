<?php
define('BASE_URL', 'http://localhost/librasys/php/');
?>
